var express = require('express');
var status = require('http-status');
var app = express();
var router = express.Router()
var port = 9001;

router.get('/',function(req,res){res.send('Its over 9000!');});

router.post('/',function(req,res){res.sendStatus(status.METHOD_NOT_ALLOWED); });

app.listen(port,function(){console.log('Listening on port ' + port);});

app.use('/',router);
