const express = require('express');
const app = express();
const router = express.Router()


router.get('/', function(req,res){res.send('Its over 9000!');});

router.post('/', function(req,res){res.sendStatus(status.METHOD_NOT_ALLOWED); });

module.exports = router;

