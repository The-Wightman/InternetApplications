var express = require('express');
var status = require('http-status');
var app = express();
var router = require('./routes/hello.js');
var port = 9001;

app.listen(port,function(){console.log('Listening on port ' + port);});

app.use('/',router);
